

$( document ).ready(function() {

});


function ajax(){
    let xhr = new XMLHttpRequest;
    xhr.open('GET', 'https://jsonplaceholder.typicode.com/todos', true);
    
    xhr.onload = function() 
    {
      if (this.status == 200) 
      { 
        // alert("hi");
        let data = JSON.parse(this.responseText),
        tbodyHtml = '';              
        data.map(function(d) {
              tbodyHtml += `
              <tr>
              <th colspan="2">${d.id}</th>
              <td colspan="2">${d.title}</td>
              <td colspan="2">${d.completed}</td>
              <td colspan="2"><input type="checkbox" name="name1" /> &nbsp;</td>
          </tr>
          `;
        });       
        document.querySelector('#todo_table tbody').innerHTML = tbodyHtml;

        // disable checkbox for true key values
        
          let c = $("input[type='checkbox']");
          for(var i=0; i< data.length ; i++){
            if(data[i].completed == "true"){
              c.attr("disabled", true);
            }
          }

          // promise

          var promise = new Promise(function(resolve,reject){
            $(':checkbox').click(function(){
              var s=$('#todo_table :input[type="checkbox"]:checked').length;
                if(s==5){
                  resolve();                      
                }
            })
          });
          promise
          .then(function(){
              alert("you have successfully completed the task");
           }) 
          .catch(function(){
              console.log("error");
          })                              
      }
    }
  xhr.send();
}
