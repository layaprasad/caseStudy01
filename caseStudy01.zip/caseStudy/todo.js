

$( document ).ready(function() {

});


function ajax(){
    let xhr = new XMLHttpRequest;
    xhr.open('GET', 'https://jsonplaceholder.typicode.com/todos', true);
    
    xhr.onload = function() 
    {
      if (this.status == 200) 
      { 
        let data = JSON.parse(this.responseText),
        // tbodyHtml = '';              
            task ='';
        $.each(data,function(key,value) {
                            
            task+='<tr>';
            task+='<td colspan="2">'+value.id+'</td>';
            task+='<td colspan="2">'+value.title+'</td>';
            task+='<td colspan="2">'+value.completed+'</td>';
            task+='<td colspan="2">';

    // disable checkbox for true key values

            if(value.completed==false){

                task+='<input type="checkbox" id="check" class="checkbox"> ';
            }

            else{
                task+='<input type="checkbox" checked disabled> ';
                }
                task+='</td>';
                task+='</tr>';
        });
        document.querySelector('#todo_table tbody').innerHTML = task;

    // promise

            var promise = new Promise(function(resolve,reject){
                $(':checkbox').click(function(){
                    var s=$('#check:checked').length;
                        if(s==5){
                        resolve();                      
                        }
                })
            });
            promise
            .then(function(){
                alert("you have successfully completed the task");
            }) 
            .catch(function(){
                console.log("error");
            })                              
        }
    }
    xhr.send();
}
