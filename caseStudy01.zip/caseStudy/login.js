

let user = document.getElementById("user");
let pwd = document.getElementById("pwd");
let errorUser  = document.getElementById("errorUser");
let errorPwd = document.getElementById("errorPwd");

// let login = document.getElementById("login");
// login.addEventListener("click" , validate(display));

function validate(display){

    if(user.value == "" || user.value != "admin"){
        errorUser.innerHTML = "Username cannot be blank or invalid";
        errorUser.style.color = "red";
        errorUser.style.fontSize = "smaller";
        return false;       
        }
    else if(pwd.value == "" || pwd.value != 12345){
        errorPwd.innerHTML = "Password cannot be blank or invalid";
        errorPwd.style.color = "red";
        errorPwd.style.fontSize = "smaller";
        return false;
        } 
    else{
        display();
    }    
}
function display(){

    window.location.href = "home.html";
   
}
